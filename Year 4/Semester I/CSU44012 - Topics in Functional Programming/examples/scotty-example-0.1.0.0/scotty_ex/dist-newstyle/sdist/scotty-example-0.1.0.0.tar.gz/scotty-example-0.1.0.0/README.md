# scotty-example

This simple Scotty example demonstrates the very basics of getting a Scotty app up and running. 
