# Parallel Fibonacci number examples

There are six Haskell source files in the src/ folder, each of which
is an example from the week 1 lectures. You can build them all using:

```stack build```

You can run an example like this:

```stack exec ex1 -- +RTS -N4```


